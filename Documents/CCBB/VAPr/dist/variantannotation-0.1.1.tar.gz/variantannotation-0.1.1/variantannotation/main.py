import os
from variantannotation import annotate_batch
from variantannotation import myvariant_parsing_utils
from variantannotation import mongo_DB_export
import annovar_subprocess

#set paths
filepath = "/Users/carlomazzaferro/Desktop/CSV to be tested"
csv_file = "Tumor_targeted_processed.csv"
vcf_file = "Tumor_targeted_seq.vqsr.vcf"

"""
ANNOVAR_PATH = '/database/annovar/'
IN_PATH = '/data/Nof1/file.vcf'
OUT_PATH = '/data/ccbb_internal/interns/Carlo/annovar_results'
os.chdir(filepath)
"""

#1. Get csv file: run annovar
annovar_subprocess.run_annovar(ANNOVAR_PATH, IN_PATH, OUT_PATH)


#METHOD 1: by chunks, iteratively
chunksize = 1000
step = 0


open_file = myvariant_parsing_utils.VariantParsing()
list_file = open_file.get_variants_from_vcf(vcf_file)


as_batch = annotate_batch.AnnotationMethods()

as_batch.by_chunks(list_file, chunksize, step, csv_file)
#236544 objects
#---------------#--------------#---------------#--------------#---------------#--------------#---------------#

#METHOD 2: parallelize everything. Add method to class AnnotationMethods to do so. Threading needed.

#get variant list. Should always be the first step after running ANNOVAR
open_file = myvariant_parsing_utils.VariantParsing()
list_file = open_file.get_variants_from_vcf(vcf_file)

as_one_file = annotate_batch.AnnotationMethods()
joint_list = as_one_file.full_file(list_file, csv_file)

#Name Collection & DB
collection_name = 'My_Variant_Collection'
db_name = 'My_Variant_Database'


exporting_function = mongo_DB_export()
exporting_function.export(joint_list, collection_name, db_name)
#257796 objects




from pymongo import MongoClient
def export(list_docs, collection_name, db_name):
    client = MongoClient()


    db = getattr(client, db_name)
    collection = getattr(db, collection_name)

    collection.insert_many(list_docs)




#option to change name of collection
#
#METHOD A: ANNOVAR + MYVARIANT.INFO




"""
#ANNOVAR
filtered_annovar = get_list_from_annovar_csv(file_name, vcf_file)

#test on smaller subsample, a huge one will take a few hours to query all the data from myvariant.info
from_annovar = filtered_annovar[0:200]


#MYVARIANT.INFO()
variant_list = myvariant_parsing_utils.get_variants_from_vcf(vcf_file)
from_myvariant = myvariant_parsing_utils.get_dict_myvariant(variant_list, chunksize)

#Join data
final_joint(from_annovar,from_myvariant)
joined_list = from_annovar

#From unicode to string
joined_list = convert(joined_list)
"""


#---------------#--------------#---------------#--------------#---------------#--------------#---------------#
#Ignore
#METHOD B: Just MYVARIANT.INFO
import os
import sys

#quick and dirty way of importing functions
sys.path.append("/Users/carlomazzaferro/Documents/Bioinformatics Internship/Python Codes/")

from myvariant_methodB import annoatation_myvariant

#set by user
filepath = "/Users/carlomazzaferro/Desktop/CSV to be tested"
vcf_file = "Tumor_targeted_seq.vqsr.vcf"
os.chdir(filepath)

from_myvariant = annoatation_myvariant(vcf_file, first_variant = 1000, last_variant= 2000)


#---------------#--------------#---------------#--------------#---------------#--------------#---------------#


"MongoDB export"

from pymongo import MongoClient

client = MongoClient()

db = client.test_database

collection = db.test_variant_annotation
collection.insert_many(from_annovar)

collection.find_one({'HGVS_id': 'chrMT:g.146T>C'})

